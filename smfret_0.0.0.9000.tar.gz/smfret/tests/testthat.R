library(testthat)
library(smfret)

test_check("smfret")
